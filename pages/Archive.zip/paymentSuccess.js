import React, { Component } from 'react';

class SuccessPage extends Component {
    state = {}
    render() {
        return (
            <div>
                <h1>
                    Successfully Made the Payment
                </h1>
            </div>
        );
    }
}

export default SuccessPage;