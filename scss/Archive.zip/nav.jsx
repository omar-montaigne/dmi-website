

import Link from "next/link";
import "../scss/navbar.scss";

const NavBar = () => {
  return (
    <nav className="clearfix">
      <div className="image-box">
        <img src="/static/Images/DMI-Logo-White.png" alt="DMI-Logo" />
      </div>

      <div className="nav-items-box">
        <ul className="clearfix">
          <li>
            <Link href="/">
              <a>
                <p>Home</p>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/">
              <a>
                <p>Industry Verticals</p>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/">
              <a>
                <p>Pipeline Analysis</p>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/">
              <a>
                <p>Our Methodology</p>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/contact">
              <a>
                <p>Contact Us</p>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/about">
              <a>
                <p>About Us</p>
              </a>
            </Link>
          </li>
        </ul>
      </div>
      <div className="nav-icons-box">
        <img src="/static/icons/shopping-cart.svg" alt="shopping-cart-icon" />
        <img src="/static/icons/search.svg" alt="search-icon" />
      </div>
    </nav>
  );
};

export default NavBar;
